
import React from 'react';
import Loader from './Loader';

interface ImageDisplayProps {
  imageUrl: string | null;
  isLoading: boolean;
  error: string | null;
  prompt: string;
}

const ImageDisplay: React.FC<ImageDisplayProps> = ({ imageUrl, isLoading, error, prompt }) => {
  const renderContent = () => {
    if (isLoading) {
      return <Loader />;
    }

    if (error) {
      return (
        <div className="text-center text-red-600 bg-red-100 p-4 rounded-lg">
          <h3 className="font-bold">Oh no!</h3>
          <p>{error}</p>
        </div>
      );
    }

    if (imageUrl) {
      return (
        <div className="animate-fade-in">
          <img
            src={imageUrl}
            alt={prompt}
            className="w-full h-auto object-contain rounded-lg shadow-xl"
          />
           <p className="text-sm text-ghibli-brown/80 mt-2 italic text-center">"{prompt}"</p>
        </div>
      );
    }

    return (
      <div className="text-center text-ghibli-brown p-4">
        <div className="animate-float">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto text-ghibli-green" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>
        </div>
        <h3 className="font-display text-2xl mt-4">Your canvas awaits</h3>
        <p>Describe the world you want to see, and let the magic begin.</p>
      </div>
    );
  };

  return (
    <div className="mt-8 min-h-[300px] w-full flex items-center justify-center bg-ghibli-cream/50 p-4 rounded-lg border-2 border-dashed border-ghibli-green/50">
      {renderContent()}
    </div>
  );
};

export default ImageDisplay;
