
import React from 'react';

const Loader: React.FC = () => {
  const messages = [
    "Consulting the forest spirits...",
    "Mixing colors from a sunset...",
    "Catching starlight for the details...",
    "Asking Totoro for artistic advice...",
    "Painting with a magical brush..."
  ];
  
  const [message, setMessage] = React.useState(messages[0]);

  React.useEffect(() => {
    const interval = setInterval(() => {
      setMessage(messages[Math.floor(Math.random() * messages.length)]);
    }, 2500);
    return () => clearInterval(interval);
     // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="flex flex-col items-center justify-center text-center text-ghibli-brown p-4">
      <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-ghibli-blue"></div>
      <p className="mt-4 font-display text-2xl transition-opacity duration-500">
        {message}
      </p>
    </div>
  );
};

export default Loader;
