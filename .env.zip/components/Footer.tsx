
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="text-center py-4 px-4">
      <p className="text-sm text-ghibli-dark/70">
        Powered by Google Gemini. Crafted with imagination.
      </p>
    </footer>
  );
};

export default Footer;
