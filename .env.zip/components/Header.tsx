
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="text-center py-8 px-4">
      <h1 className="font-display text-5xl md:text-7xl text-ghibli-dark drop-shadow-lg">
        Ghibli Art Generator
      </h1>
      <p className="text-ghibli-brown mt-2 text-lg">
        Create magical landscapes and characters with the power of AI
      </p>
    </header>
  );
};

export default Header;
