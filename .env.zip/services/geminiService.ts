/**
 * Calls the serverless API route to generate a Ghibli-style image.
 * Keeps the API key on the server.
 */
export const generateGhibliImage = async (userPrompt: string): Promise<string> => {
  const res = await fetch('/api/generate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt: userPrompt })
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || 'Failed to generate image');
  }

  const data = await res.json() as { imageDataUrl: string };
  return data.imageDataUrl;
};
