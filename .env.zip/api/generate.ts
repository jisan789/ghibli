import type { VercelRequest, VercelResponse } from '@vercel/node';
import { GoogleGenAI } from '@google/genai';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    res.status(500).json({ error: 'Server misconfiguration: GEMINI_API_KEY missing' });
    return;
  }

  const { prompt } = req.body as { prompt?: string };
  if (!prompt || !prompt.trim()) {
    res.status(400).json({ error: 'Prompt is required' });
    return;
  }

  const ai = new GoogleGenAI({ apiKey });

  const fullPrompt = `Masterpiece, best quality, Studio Ghibli style art of ${prompt}. Whimsical, detailed, soft painterly lighting, vibrant yet gentle color palette, hand-drawn anime aesthetic, cinematic composition.`;

  try {
    const response = await ai.models.generateImages({
      model: 'imagen-3.0-generate-002',
      prompt: fullPrompt,
      config: {
        numberOfImages: 1,
        outputMimeType: 'image/jpeg',
        aspectRatio: '16:9',
      },
    });

    if (!response.generatedImages || response.generatedImages.length === 0) {
      res.status(502).json({ error: 'No images were generated' });
      return;
    }

    const base64ImageBytes = response.generatedImages[0].image.imageBytes;
    res.status(200).json({ imageDataUrl: `data:image/jpeg;base64,${base64ImageBytes}` });
  } catch (err: any) {
    console.error('Gemini API error:', err);
    res.status(500).json({ error: 'Failed to generate image' });
  }
}

